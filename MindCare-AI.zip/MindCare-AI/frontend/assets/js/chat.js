// chat.js - Chat Functionality

const chat = {
    // Chat state
    messages: [],
    emotions: [],
    isTyping: false,
    isVoiceActive: false,
    privacyMode: false,
    
    // Initialize chat
    init: function() {
        this.loadMessages();
        this.setupEventListeners();
        this.updateEmotionDisplay();
        this.loadEmotionTimeline();
        
        // Start periodic emotion check
        setInterval(() => this.checkEmotions(), 60000);
    },
    
    // Setup event listeners
    setupEventListeners: function() {
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        const voiceToggle = document.getElementById('voiceToggle');
        const toggleVoiceBtn = document.getElementById('toggleVoice');
        
        // Send message on Enter (but allow Shift+Enter for new line)
        messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Auto-resize textarea
        messageInput.addEventListener('input', this.autoResizeTextarea);
        
        // Send button click
        sendButton.addEventListener('click', () => this.sendMessage());
        
        // Voice toggle
        voiceToggle.addEventListener('click', () => this.toggleVoiceRecording());
        toggleVoiceBtn?.addEventListener('click', () => this.toggleVoiceRecording());
        
        // Load messages on scroll
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.addEventListener('scroll', this.handleScroll.bind(this));
    },
    
    // Auto-resize textarea
    autoResizeTextarea: function() {
        const textarea = this;
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    },
    
    // Send message
    sendMessage: function() {
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();
        
        if (!message) return;
        
        // Add user message
        this.addMessage(message, 'user');
        
        // Clear input and reset height
        messageInput.value = '';
        messageInput.style.height = 'auto';
        
        // Analyze emotion from message
        const emotion = this.analyzeEmotion(message);
        this.emotions.push({
            emotion: emotion.name,
            level: emotion.level,
            timestamp: new Date().toISOString(),
            message: message
        });
        
        // Update emotion display
        this.updateEmotionDisplay();
        this.addEmotionToTimeline(emotion);
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Simulate AI response (in real app, this would be an API call)
        setTimeout(() => {
            this.hideTypingIndicator();
            this.generateAIResponse(message, emotion);
        }, 1000 + Math.random() * 2000);
    },
    
    // Add message to chat
    addMessage: function(text, sender, type = 'text') {
        const chatMessages = document.getElementById('chatMessages');
        const messageId = Date.now();
        
        const message = {
            id: messageId,
            text: text,
            sender: sender,
            type: type,
            timestamp: new Date().toISOString(),
            read: true
        };
        
        this.messages.push(message);
        
        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        messageDiv.dataset.id = messageId;
        
        const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        let messageContent = '';
        if (type === 'text') {
            messageContent = `
                <div class="message-header">
                    <div class="avatar ${sender}-avatar">
                        <i class="bi bi-${sender === 'user' ? 'person' : 'robot'}"></i>
                    </div>
                    <div>
                        <strong>${sender === 'user' ? 'You' : 'MindCare AI'}</strong>
                        <small class="text-muted ms-2">${time}</small>
                    </div>
                </div>
                <div class="message-content">
                    ${this.formatMessage(text)}
                </div>
            `;
        } else if (type === 'system') {
            messageContent = `
                <div class="message-content">
                    <i class="bi bi-info-circle me-1"></i>
                    ${text}
                </div>
            `;
        }
        
        messageDiv.innerHTML = messageContent;
        
        // Add to chat
        chatMessages.appendChild(messageDiv);
        
        // Scroll to bottom
        this.scrollToBottom();
        
        // Save messages
        this.saveMessages();
        
        return messageDiv;
    },
    
    // Format message with links, emojis, etc.
    formatMessage: function(text) {
        // Convert URLs to links
        text = text.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" class="text-primary">$1</a>');
        
        // Convert newlines to <br>
        text = text.replace(/\n/g, '<br>');
        
        return text;
    },
    
    // Generate AI response
    generateAIResponse: function(userMessage, emotion) {
        // This is a simplified version - in reality, this would call an AI API
        
        const responses = {
            stressed: [
                "I can sense you're feeling stressed. Would you like to try a quick breathing exercise?",
                "Stress during studies is completely normal. Remember to take breaks and be kind to yourself.",
                "Let's break down what's causing the stress. Would you like to talk about it?"
            ],
            anxious: [
                "I notice you're feeling anxious. Let's practice some grounding techniques together.",
                "Anxiety can feel overwhelming, but you're not alone. Want to try a calming activity?",
                "Take a deep breath with me. Inhale for 4 seconds, hold for 4, exhale for 6."
            ],
            lonely: [
                "I hear you're feeling lonely. Remember that many students feel this way, especially during exams.",
                "Would you like me to suggest some campus resources for connecting with others?",
                "Sometimes writing down thoughts can help. Want to try some journaling prompts?"
            ],
            calm: [
                "It's wonderful that you're feeling calm. Want to practice some mindfulness to maintain this state?",
                "Great energy! This is a good time to work on building resilience skills.",
                "Would you like to learn some techniques to help maintain this peaceful state?"
            ],
            default: [
                "Thank you for sharing. How does that make you feel?",
                "I'm here to listen. Can you tell me more about that?",
                "That sounds challenging. Would you like some support strategies?"
            ]
        };
        
        let responseType = emotion.name.toLowerCase();
        if (!responses[responseType]) {
            responseType = 'default';
        }
        
        const randomResponse = responses[responseType][Math.floor(Math.random() * responses[responseType].length)];
        
        // Add AI message
        const messageDiv = this.addMessage(randomResponse, 'bot');
        
        // Add quick suggestions based on emotion
        setTimeout(() => {
            this.addQuickSuggestions(emotion.name);
        }, 500);
        
        return messageDiv;
    },
    
    // Add quick suggestions
    addQuickSuggestions: function(emotion) {
        const suggestions = {
            stressed: [
                "Start 4-7-8 breathing",
                "Try progressive muscle relaxation",
                "Take a 5-minute walk"
            ],
            anxious: [
                "Grounding technique: 5-4-3-2-1",
                "Listen to calming sounds",
                "Write down worries"
            ],
            lonely: [
                "Reach out to a friend",
                "Join an online study group",
                "Visit campus counseling"
            ],
            calm: [
                "Start gratitude journal",
                "Meditation session",
                "Plan self-care activities"
            ]
        };
        
        if (!suggestions[emotion.toLowerCase()]) return;
        
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot-message';
        messageDiv.innerHTML = `
            <div class="message-suggestions">
                ${suggestions[emotion.toLowerCase()].map(text => `
                    <button class="btn btn-sm btn-outline-primary" onclick="chat.quickAction('${text}')">
                        ${text}
                    </button>
                `).join('')}
            </div>
        `;
        
        document.getElementById('chatMessages').appendChild(messageDiv);
        this.scrollToBottom();
    },
    
    // Quick action from suggestions
    quickAction: function(action) {
        this.addMessage(action, 'user');
        
        // Process the quick action
        if (action.includes('breathing')) {
            this.breathingExercise();
        } else if (action.includes('grounding')) {
            this.addMessage("Let's do the 5-4-3-2-1 grounding exercise. Notice 5 things you can see...", 'bot');
        } else if (action.includes('walk')) {
            this.addMessage("Great idea! A short walk can boost mood and reduce stress. Want to set a timer?", 'bot');
        }
        
        this.showTypingIndicator();
        setTimeout(() => {
            this.hideTypingIndicator();
            this.addMessage("How did that feel? Want to try another activity?", 'bot');
        }, 1500);
    },
    
    // Quick response buttons
    quickResponse: function(text) {
        document.getElementById('messageInput').value = text;
        this.sendMessage();
    },
    
    // Analyze emotion from text
    analyzeEmotion: function(text) {
        const emotions = {
            stressed: ['stress', 'overwhelmed', 'pressure', 'burnout', 'tired', 'exhausted'],
            anxious: ['anxious', 'worried', 'nervous', 'panic', 'scared', 'fear'],
            lonely: ['lonely', 'alone', 'isolated', 'disconnected', 'homesick'],
            calm: ['calm', 'peaceful', 'relaxed', 'good', 'happy', 'content'],
            sad: ['sad', 'depressed', 'down', 'unhappy', 'hopeless']
        };
        
        text = text.toLowerCase();
        let detectedEmotion = 'neutral';
        let level = 3;
        
        for (const [emotion, keywords] of Object.entries(emotions)) {
            for (const keyword of keywords) {
                if (text.includes(keyword)) {
                    detectedEmotion = emotion;
                    level = Math.min(10, 5 + Math.random() * 5); // Random level 5-10
                    break;
                }
            }
            if (detectedEmotion !== 'neutral') break;
        }
        
        return {
            name: detectedEmotion.charAt(0).toUpperCase() + detectedEmotion.slice(1),
            level: level,
            color: this.getEmotionColor(detectedEmotion)
        };
    },
    
    // Get emotion color
    getEmotionColor: function(emotion) {
        const colors = {
            stressed: '#f59e0b',
            anxious: '#ef4444',
            lonely: '#8b5cf6',
            calm: '#10b981',
            sad: '#0ea5e9',
            neutral: '#94a3b8'
        };
        
        return colors[emotion] || colors.neutral;
    },
    
    // Update emotion display
    updateEmotionDisplay: function() {
        if (this.emotions.length === 0) return;
        
        const latestEmotion = this.emotions[this.emotions.length - 1];
        const emotionName = document.getElementById('emotionName');
        const emotionLevel = document.getElementById('emotionLevel');
        const emotionValue = document.getElementById('emotionValue');
        const emotionIcon = document.querySelector('.emotion-icon-lg i');
        
        if (emotionName) emotionName.textContent = latestEmotion.emotion;
        if (emotionLevel) {
            const percentage = (latestEmotion.level / 10) * 100;
            emotionLevel.style.width = `${percentage}%`;
            emotionLevel.className = `progress-bar ${this.getEmotionClass(latestEmotion.emotion.toLowerCase())}`;
        }
        if (emotionValue) emotionValue.textContent = `${latestEmotion.level}/10`;
        if (emotionIcon) {
            emotionIcon.className = this.getEmotionIcon(latestEmotion.emotion.toLowerCase());
        }
    },
    
    // Get emotion class for styling
    getEmotionClass: function(emotion) {
        const classes = {
            stressed: 'bg-warning',
            anxious: 'bg-danger',
            lonely: 'bg-info',
            calm: 'bg-success',
            sad: 'bg-primary',
            neutral: 'bg-secondary'
        };
        
        return classes[emotion] || 'bg-secondary';
    },
    
    // Get emotion icon
    getEmotionIcon: function(emotion) {
        const icons = {
            stressed: 'bi bi-emoji-frown',
            anxious: 'bi bi-emoji-dizzy',
            lonely: 'bi bi-emoji-expressionless',
            calm: 'bi bi-emoji-smile',
            sad: 'bi bi-emoji-tear',
            neutral: 'bi bi-emoji-neutral'
        };
        
        return icons[emotion] || 'bi bi-emoji-neutral';
    },
    
    // Add emotion to timeline
    addEmotionToTimeline: function(emotion) {
        const timeline = document.getElementById('emotionTimeline');
        if (!timeline) return;
        
        const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        const item = document.createElement('div');
        item.className = 'emotion-timeline-item';
        item.innerHTML = `
            <div class="emotion-timeline-icon" style="background: rgba(${this.hexToRgb(emotion.color)}, 0.2); border: 1px solid ${emotion.color}; color: ${emotion.color}">
                <i class="${this.getEmotionIcon(emotion.name.toLowerCase())}"></i>
            </div>
            <div class="emotion-timeline-content">
                <h6>${emotion.name}</h6>
                <p>Level: ${emotion.level}/10</p>
            </div>
            <div class="emotion-timeline-time">${time}</div>
        `;
        
        timeline.insertBefore(item, timeline.firstChild);
        
        // Limit timeline items
        if (timeline.children.length > 10) {
            timeline.removeChild(timeline.lastChild);
        }
    },
    
    // Load emotion timeline
    loadEmotionTimeline: function() {
        // Load from localStorage or generate sample data
        const savedEmotions = localStorage.getItem('chatEmotions');
        if (savedEmotions) {
            this.emotions = JSON.parse(savedEmotions);
        } else {
            // Generate sample emotions for demo
            const sampleEmotions = [
                { emotion: 'Calm', level: 8, timestamp: '2024-01-15T10:30:00', message: 'Feeling good today' },
                { emotion: 'Stressed', level: 6, timestamp: '2024-01-15T09:15:00', message: 'Exam pressure' },
                { emotion: 'Anxious', level: 7, timestamp: '2024-01-14T16:45:00', message: 'Presentation tomorrow' },
                { emotion: 'Calm', level: 9, timestamp: '2024-01-14T11:20:00', message: 'Meditation helped' },
                { emotion: 'Lonely', level: 5, timestamp: '2024-01-13T20:10:00', message: 'Missing home' }
            ];
            
            this.emotions = sampleEmotions;
        }
        
        // Update display
        this.updateEmotionDisplay();
        
        // Populate timeline
        const timeline = document.getElementById('emotionTimeline');
        if (timeline) {
            timeline.innerHTML = '';
            this.emotions.slice(-10).reverse().forEach(emotion => {
                const time = new Date(emotion.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                const color = this.getEmotionColor(emotion.emotion.toLowerCase());
                
                const item = document.createElement('div');
                item.className = 'emotion-timeline-item';
                item.innerHTML = `
                    <div class="emotion-timeline-icon" style="background: rgba(${this.hexToRgb(color)}, 0.2); border: 1px solid ${color}; color: ${color}">
                        <i class="${this.getEmotionIcon(emotion.emotion.toLowerCase())}"></i>
                    </div>
                    <div class="emotion-timeline-content">
                        <h6>${emotion.emotion}</h6>
                        <p>Level: ${emotion.level}/10</p>
                    </div>
                    <div class="emotion-timeline-time">${time}</div>
                `;
                timeline.appendChild(item);
            });
        }
    },
    
    // Convert hex to RGB
    hexToRgb: function(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? 
            `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}` : 
            '148, 163, 184';
    },
    
    // Check emotions periodically
    checkEmotions: function() {
        if (this.messages.length === 0) return;
        
        // In a real app, this would analyze conversation history
        // For demo, we'll just update randomly
        if (Math.random() > 0.7) {
            const emotions = ['Calm', 'Stressed', 'Anxious', 'Lonely', 'Neutral'];
            const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
            const randomLevel = Math.floor(Math.random() * 6) + 3;
            
            this.emotions.push({
                emotion: randomEmotion,
                level: randomLevel,
                timestamp: new Date().toISOString(),
                message: 'Periodic check'
            });
            
            this.updateEmotionDisplay();
            this.addEmotionToTimeline({
                name: randomEmotion,
                level: randomLevel,
                color: this.getEmotionColor(randomEmotion.toLowerCase())
            });
            
            this.saveEmotions();
        }
    },
    
    // Show typing indicator
    showTypingIndicator: function() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.style.display = 'block';
            this.isTyping = true;
        }
    },
    
    // Hide typing indicator
    hideTypingIndicator: function() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.style.display = 'none';
            this.isTyping = false;
        }
    },
    
    // Toggle voice recording
    toggleVoiceRecording: function() {
        this.isVoiceActive = !this.isVoiceActive;
        const voiceToggle = document.getElementById('voiceToggle');
        const toggleVoiceBtn = document.getElementById('toggleVoice');
        
        if (this.isVoiceActive) {
            // Start recording
            if (voiceToggle) {
                voiceToggle.innerHTML = '<i class="bi bi-mic-fill"></i>';
                voiceToggle.classList.add('voice-recording');
            }
            if (toggleVoiceBtn) {
                toggleVoiceBtn.innerHTML = '<i class="bi bi-mic-fill"></i>';
                toggleVoiceBtn.classList.add('voice-recording');
            }
            
            this.addSystemMessage("Voice recording started...");
            
            // In real app, this would start actual voice recording
            setTimeout(() => {
                // Simulate voice input
                const simulatedText = "I'm feeling a bit anxious about my exams";
                document.getElementById('messageInput').value = simulatedText;
                this.sendMessage();
                this.toggleVoiceRecording(); // Turn off
            }, 3000);
            
        } else {
            // Stop recording
            if (voiceToggle) {
                voiceToggle.innerHTML = '<i class="bi bi-mic"></i>';
                voiceToggle.classList.remove('voice-recording');
            }
            if (toggleVoiceBtn) {
                toggleVoiceBtn.innerHTML = '<i class="bi bi-mic"></i>';
                toggleVoiceBtn.classList.remove('voice-recording');
            }
            
            this.addSystemMessage("Voice recording stopped");
        }
    },
    
    // Add system message
    addSystemMessage: function(text) {
        this.addMessage(text, 'system', 'system');
    },
    
    // Suggest activity
    suggestActivity: function() {
        const activities = [
            "Try 5 minutes of mindful breathing",
            "How about a quick body scan meditation?",
            "Let's do a gratitude journal exercise",
            "Want to try progressive muscle relaxation?",
            "Let's practice the 5-4-3-2-1 grounding technique"
        ];
        
        const randomActivity = activities[Math.floor(Math.random() * activities.length)];
        this.addMessage(`Suggestion: ${randomActivity}`, 'bot');
    },
    
    // Start game
    startGame: function() {
        this.addMessage("Opening calming game... Redirecting to games section.", 'bot');
        // In real app, this would redirect to games.html
        setTimeout(() => {
            alert("This would redirect to calming games. For demo, staying here.");
        }, 1000);
    },
    
    // Breathing exercise
    breathingExercise: function() {
        this.addMessage("Let's do the 4-7-8 breathing exercise. Follow along:", 'bot');
        
        const steps = [
            "Exhale completely through your mouth",
            "Inhale quietly through your nose for 4 seconds",
            "Hold your breath for 7 seconds",
            "Exhale completely through your mouth for 8 seconds"
        ];
        
        steps.forEach((step, index) => {
            setTimeout(() => {
                this.addMessage(`${index + 1}. ${step}`, 'bot');
            }, (index + 1) * 3000);
        });
        
        setTimeout(() => {
            this.addMessage("Great job! Repeat this cycle 3-4 times for maximum benefit.", 'bot');
        }, (steps.length + 1) * 3000);
    },
    
    // Clear chat
    clearChat: function() {
        if (confirm("Are you sure you want to clear the chat? This cannot be undone.")) {
            const chatMessages = document.getElementById('chatMessages');
            chatMessages.innerHTML = '';
            this.messages = [];
            this.saveMessages();
            
            // Add welcome message back
            setTimeout(() => {
                this.addMessage("Hello! 👋 I'm MindCare, your AI mental health companion. I'm here to listen without judgment.", 'bot');
                this.addMessage("You can talk to me about anything - stress, anxiety, academic pressure, or just how your day is going. How are you feeling today?", 'bot');
            }, 500);
        }
    },
    
    // Export chat
    exportChat: function() {
        const chatData = {
            messages: this.messages,
            emotions: this.emotions,
            exportedAt: new Date().toISOString()
        };
        
        const dataStr = JSON.stringify(chatData, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = `mindcare-chat-${new Date().toISOString().split('T')[0]}.json`;
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        
        this.addSystemMessage("Chat exported successfully");
    },
    
    // Toggle privacy mode
    togglePrivacy: function() {
        this.privacyMode = !this.privacyMode;
        
        if (this.privacyMode) {
            this.addSystemMessage("Privacy mode enabled: Messages will not be stored");
        } else {
            this.addSystemMessage("Privacy mode disabled: Messages will be stored locally");
        }
    },
    
    // Add emoji to input
    addEmoji: function(emoji) {
        const input = document.getElementById('messageInput');
        input.value += emoji;
        input.focus();
    },
    
    // Scroll to bottom
    scrollToBottom: function() {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.scrollTop = chatMessages.scrollHeight;
    },
    
    // Handle scroll for loading more messages
    handleScroll: function() {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages.scrollTop === 0) {
            // Load more messages if available
            this.loadMoreMessages();
        }
    },
    
    // Load more messages (for pagination)
    loadMoreMessages: function() {
        // In a real app, this would load older messages from server
        console.log("Loading more messages...");
    },
    
    // Load messages from storage
    loadMessages: function() {
        if (this.privacyMode) return;
        
        const savedMessages = localStorage.getItem('chatMessages');
        if (savedMessages) {
            this.messages = JSON.parse(savedMessages);
            this.renderMessages();
        }
    },
    
    // Render all messages
    renderMessages: function() {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = '';
        
        this.messages.forEach(msg => {
            this.addMessage(msg.text, msg.sender, msg.type);
        });
        
        this.scrollToBottom();
    },
    
    // Save messages to storage
    saveMessages: function() {
        if (this.privacyMode) return;
        
        localStorage.setItem('chatMessages', JSON.stringify(this.messages));
    },
    
    // Save emotions to storage
    saveEmotions: function() {
        localStorage.setItem('chatEmotions', JSON.stringify(this.emotions));
    }
};

// Make chat object globally available
window.chat = chat;