// Mock API endpoints for demo purposes
const API_ENDPOINTS = {
    analyzeEmotion: '/api/analyze-emotion',
    getActivities: '/api/activities',
    getGames: '/api/games',
    saveProgress: '/api/progress',
    getCounselors: '/api/counselors',
    speechToText: '/api/speech-to-text',
    textToSpeech: '/api/text-to-speech'
};

export class MindCareAPI {
    constructor() {
        this.baseURL = 'https://api.mindcare-ai.demo';
        this.authToken = localStorage.getItem('mindcare_token');
    }

    async analyzeSentiment(text) {
        // Mock implementation - replace with actual API call
        return new Promise(resolve => {
            setTimeout(() => {
                const mockResponse = {
                    score: Math.random() * 2 - 1, // -1 to 1
                    magnitude: Math.random(),
                    emotions: ['STRESSED', 'ANXIOUS', 'OVERWHELMED'].filter(() => Math.random() > 0.5),
                    suggested_actions: ['breathing_exercise', 'take_break', 'talk_to_someone']
                };
                resolve(mockResponse);
            }, 500);
        });
    }

    async getActivities(type = null) {
        const response = await fetch('assets/data/activities.json');
        const data = await response.json();
        
        if (type) {
            return data.activities.filter(activity => activity.type === type);
        }
        return data.activities;
    }

    async getGames(difficulty = null) {
        const response = await fetch('assets/data/games.json');
        const data = await response.json();
        
        if (difficulty) {
            return data.games.filter(game => game.difficulty === difficulty);
        }
        return data.games;
    }

    async getCounselors(location = null) {
        // Mock counselor data
        const counselors = [
            {
                id: 1,
                name: "Dr. Sarah Johnson",
                specialization: "Academic Stress",
                availability: "Mon-Fri 9AM-5PM",
                contact: "counselor1@university.edu",
                rating: 4.8
            },
            // Add more counselors...
        ];
        
        return counselors;
    }

    async saveUserProgress(data) {
        // Mock save to localStorage
        localStorage.setItem('mindcare_user_progress', JSON.stringify(data));
        return { success: true, message: 'Progress saved' };
    }

    async exportUserData() {
        const data = {
            emotion_history: JSON.parse(localStorage.getItem('mindcare_emotion_history') || '[]'),
            chat_history: JSON.parse(localStorage.getItem('mindcare_chat_history') || '[]'),
            activity_history: JSON.parse(localStorage.getItem('mindcare_activity_history') || '[]'),
            game_history: JSON.parse(localStorage.getItem('mindcare_game_history') || '[]')
        };
        
        // Create downloadable JSON
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `mindcare_data_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        
        return { success: true };
    }
}

export const api = new MindCareAPI();